## Making Exceptions

### Instructions:

* Without removing any of the lines from the starter code provided, create `try` and `except` blocks that will allow the application to run without terminating.

* Each `except` block should handle the specific error that will occur.

* Add a `print` statement under the `except` block to log the error.
