# Instructions

Consider the following list of movie titles.

```python
movies = ["Aliens", "Sing", "Moana"]
```

Make a request to the OMDb API for each movie in the list. Then:

1. Print the director of each movie

2. Save the responses in another list

- - -

## Copyright

Data Boot Camp © 2018. All Rights Reserved.
