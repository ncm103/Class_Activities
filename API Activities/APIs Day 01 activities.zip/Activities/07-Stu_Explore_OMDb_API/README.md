# OMDb API

* **Instructions:**

  * Read the OMDb documentation, and make a few API calls to
    get some information about your favorite movie: <http://www.omdbapi.com/>

- - -

## Copyright

Data Boot Camp © 2018. All Rights Reserved.
